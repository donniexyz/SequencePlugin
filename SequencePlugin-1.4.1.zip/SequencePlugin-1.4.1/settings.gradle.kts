rootProject.name = "SequencePlugin"

